Image
Hej,
Vår kund Kungliga tekniska högskolan söker en Förändringsledare ekonomi, nivå 3 eller 4

ID: V-2024-0788
Ramavtal: IT-konsulttjänster Resurskonsulter - Delområde 2, Ledning av IT-projekt, 23.3-2940-20

Omfattning: 100 %
Placering: Stockholm
Avtalstid: 2024-12-02 – 2025-12-01, med option till förlängning max 6 gånger á 6 månader

Uppdragsbeskrivning:
IT-avdelningen vid Kungliga Tekniska högskolan behöver en förändringsledare, till ett projekt som implementerar en ny process med nytt systemstöd för budgetering och prognostisering på KTH.
Konsulten kommer att jobba som förändringsledare i projektet Budget & prognos för KTH:s Ekonomi-verksamhet. Förändringsledaren kommer att ha ansvar för att stödja beställarens och verksamhetens förändringsarbete. Målet är ge dessa bästa förutsättningar för att den verksamhet och de användare som berörs av förändringen är väl införstådda med motiven till förändringen och att de är väl förberedda på att arbeta efter en ny process med nya systemstöd. Det innebär att man i rollen står med ett ben i projektet och ett ben i verksamheten som berörs av förändringen. Tillsammans med projektledaren verkar man även för att de som kommer att förvalta lösningen och de som ska supporta verksamheten är precis lika förberedd på nya arbetsuppgifter. Konsulten måste ha en mycket god förmåga att samverka med chefer och andra stakeholders för att driva förändringsarbetet framåt enligt vedertagna metoder. I rollen ingår utöver ledarskap och taktiskt arbete även en väsentlig del operativt arbete som att förbereda informationsmöten, utbildningar, material och liknande.

Förändringsledarens ansvar:
Ansvarig för planering, verkställande och uppföljning av förändringsaktiviteter enligt projektplan i samarbete med beställare och verksamhet.
Coacha, utbilda och leda beställare och verksamhet samt resurser inom projektet enligt plan.
Motivera mottagande verksamhet och användare till förändringen.
Upprätthålla kunskap om projektets målgrupper och intressenter och säkerställa god kunskap om deras behov med anledning av förändringen.
Utföra operativt arbete som att ta fram utbildningsmaterial, hålla workshops etc.
Följa upp utfall och rapportera till projektledare.
Bidra till ökad kunskap om förändringsledning i KTH:s utvecklingsorganisation.

Arbetet bedrivs i nära samarbete och samförstånd med uppdragets övriga resurser, i synnerhet med projektledaren, men också med externa intressenter och chefer. Utöver detta ingår även att samverka med andra ledande förmågor på enheten för att utbyta erfarenhet och kunskap inom sin domän.
För uppdraget söks en erfaren konsult.

Konsulten kan bemannas i andra uppdrag med motsvarande roll och kravprofil. Tjänsten är på heltid, och arbetet är förlagt till KTH:s lokaler i Stockholm. Det finns möjlighet att utföra en del av arbetet på distans efter överenskommelse med Beställaren. Hybridarbete är väl fungerande på enheten.

SKA-KRAV:
Konsulten kan starta uppdraget senast 2024-12-16
Konsulten ska ha minst 3 års arbetslivserfarenhet i rollen som förändringsledare inom de senaste 10 åren.
Konsulten ska ha minst 2 års arbetslivserfarenhet av en ledande roll i en förändring beroende på systemimplementation inom de senaste 10 åren.
Konsulten ska ha minst 2 års arbetslivserfarenhet i rollen som förändringsledare i stora organisationer (större än 500 medarbetare) inom de senaste 10 åren.
Konsulten ska ha minst 3 års arbetslivserfarenhet av att leda och arbeta operativt nära chefer, användare och systemförvaltare i mottagande verksamhet inom de senaste 10 åren.
Konsulten ska ha mycket god förmåga att samarbeta med interna och externa intressenter (kommer att verifieras under eventuell konsultintervju).
Konsulten ska ha mycket god förmåga att uttrycka sig i tal och skrift på svenska och engelska (kommer att verifieras under eventuell konsultintervju)

BÖR-KRAV (mervärde):
Konsulten bör ha minst 2 års arbetslivserfarenhet av en ledande roll för implementation av systemstöd för budgetprocesser.
Konsulten bör ha minst 2 års arbetslivserfarenhet av operativ/praktisk förändringsledning (kommunikation, workshops, utbildningar mm) inom de senaste 10 åren.
Konsulten bör ha en certifiering i förändringsledning inom de senaste 5 åren.

REFERENS:
Föreslagen konsult för uppdraget kommer att få presentera sig och berätta om de tidigare uppdrag som lämnats som referens samt hur de förhåller sig till KTH:s uppdrag.
INTERVJU (mervärde):
För slutgiltig utvärdering görs konsultintervju. Detta beräknas ta 1-1,5 h/möte och sker företrädesvis i KTH:s lokaler eller i andra hand digitalt via Zoom. Intervjupanelen, tillika utvärderingsgrupp, kommer utgöras av personer från IT-avdelningen.
KTH kommer att genomföra intervjuerna under perioden vecka 45-46.
Föreslagen konsult för uppdraget kommer att få presentera sig och berätta om de tidigare uppdrag som lämnats som referens samt hur de förhåller sig till KTH:s uppdrag.

CV:
Ska inkludera beskrivningar av hur konsulten uppfyller ska- och börkrav genom tidigare erfarenhet. Samt vara på svenska.

Svarstid & svarssätt:
Vänligen inkom med er intresseanmälan och cv senast 2024-10-18 till ramavtal@chas.se.

Med vänlig hälsning

Chas Partner Network AB
Chas Partner Network | Stubbsundsvägen 11 | S-131 41 Nacka
www.chas.se | ramavtal@chas.se | Direct: 073-517 10 16 : Växel 08-744 55 49
Does you consultant firm/consultant broker need a complete suite of business systems incl. time report. www.oden.bi

Want a new job? Chas was awarded as the best Employer in Europe - in Europes biggest Business Award Competition (European Business Awards)
Need better Business System? If your consultant firm/consultant broker need a complete suite of business systems incl. time report, sales, recruit, revenueand more in one and the same system? Visit www.oden.bi

Disclaimer
This e-mail is strictly confidential and may also be legally privileged. If you are not the addressee please do not read, print, re-transmit, store or act in reliance on it or any attachments. Instead, please email it back to the sender and then immediately permanently delete it. Chas Visual Management does not accept legal responsibility for this message. Any comments presented are solely those of the author and do not represent those of Chas Visual Management.
