logo
New Request- Senior Test Manager- HR
Hi,

emagine is looking for a Senior Test Manager with previous experience from ERP/HR-systems for an assignment for one of our great tech clients.

Start: 2024-11-06

Duration: 6 months to start with, but assignment can be up 1-2 years long

Location: Stockholm, hybrid

About the role

Our client is doing a global Oracle Fusion ERP and HCM implementation program. This program encompasses separate projects for ERP and HCM, each managed by distinct Service Integrators. To ensure seamless integration and superior quality across the program, they are seeking a skilled Test Manager to operate at the program level and oversee testing activities for both projects.

what you will do

Assume a critical role in ensuring the successful delivery and quality assurance of our new and global enterprise solutions. Working closely with our service Integrator managing the HCM project, you will be responsible for coordinating testing efforts, establishing common testing standards, and ensuring alignment with program objectives. This role demands exceptional leadership skills, strategic thinking, and a proven track record in managing testing activities at a program level.

Lead the testing activities at the program level for the global HCM implementation program.

Collaborate with separate Service Integrators managing the HCM projects to establish common testing standards, processes, and methodologies.

Develop a comprehensive testing strategy that encompasses HCM projects, ensuring alignment with program objectives and timelines.

Define test plans, test cases, and test scenarios to ensure thorough test coverage across all program components.

Coordinate with project teams to prioritize testing activities, allocate resources, and track progress against established milestones.

Monitor and report on the status of testing activities, including defect identification, resolution, and overall test coverage.

Implement quality assurance processes and best practices to drive continuous improvement and ensure adherence to program standards.

Serve as a point of contact for testing-related inquiries, escalations, and issue resolution at the program level.

Conduct risk assessments and develop mitigation strategies to address potential roadblocks and ensure successful program delivery.

Provide leadership, guidance, and mentorship to testing teams across HCM projects, fostering a culture of excellence and collaboration.

Your profile

You must have a strong background in QA and testing, coupled with experience in managing testing activities at a program level for large-scale implementation programs.

Extensive experience in QA and testing roles, preferably with a focus on large-scale ERP and/or HCM implementation programs.

Proven track record of managing testing activities at a program level, coordinating across multiple projects and Service Integrators.

Strong understanding of software testing methodologies, tools, and best practices.

Excellent leadership, communication, and stakeholder management skills.

Ability to thrive in a fast-paced, dynamic environment and adapt to changing priorities.

Certification in software testing and project management is a plus.

Potential long term need with a extension of 1 to 2 years depending on the need.

Kind regards,

Taher Sateri
Key Account Manager
taher@emagine-consulting.se
+46 72 204 12 40
