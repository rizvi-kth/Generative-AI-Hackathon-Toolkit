logo
New Request - Project Manager (Gap development & Migration)
Dear ,

Emagine are now looking for a Project Manager for the Gap development & Migration of Corporate Cards to one of our nordic banking clients.

Start: 2024-11-01
Slut: 2026-06-30
Location: Stockholm (3 days onsite, 2 days remote)

Role/Assignment Overview:

Gap development & migration of Corporate Cards from AirPlus to SEB Kort target solution. The project is challenging and will require close collaboration between Teams at AirPlus (Germany) and at SEB Kort (Stockholm). Majority of development in Stockholm - teams are highly motivated and skilled. SEB Kort has a large corporate card portfolio and is the European Market leader for Corporate Cards. The migration will involve migrating a portfolio with a size of roughly 40% of the existing SEB Kort corporate portfolio. In addition SEB Kort has private cards and the portfolio will be 10% of the total volume. The Corporate cards migrated are issued in a handfull of countries in Europé with the largest volumes in Germany & UK.

The ideal candidate has experience in financial payment systems and migration of customer & financial data from one ERP system to another. The volumes involved means that migration is a fully automated process. The data to be migrated will be extracted by teams in Germany and imported into target ledger by teams in Stockholm. Focus will be on making the migration as smooth as possible for the card holder and high precision in provided electronic feeds to invoicing & Travel Expense Management systems.

Development are carried out by our agile teams - and interfacing with the agile methodoly in a SaFE environment will be needed. One team focused on migrations will be available - but has one ongoing migration when the project starts. For other affected teams this will be a priority 1 effort (after regulatory & daily operations). Excellent people & communication skills are needed since the process involves getting two organisations to collaborate. Focus will be on getting the job done, remove impediments not on reporting, since a close collaboration will take place with Program management.

Endi Dedic
Business Manager
endi@emagine-consulting.se
+46 73 802 21 02
