Bakgrund:
Uppdraget är att ersätta en befintlig projektledare inom två pågående projekt, samt ta eventuellt ta kommande uppdrag i väntan på att ersättningsrekrytering slutförs. Befintlig projektledare slutar vid årsskiftet. Ersättningsrekryteringen påbörjad parallellt.

Pågående projekt #1:

Windows 11 – Del 2 (100% nov-dec 2024, 50% jan-nov 2025)

Under 2023-24 har IT etablerat en tjänst för att uppgradera koncernens alla datorer till Windows 11, samt byta de datorer som inte klarar av systemkraven. Nu påbörjas arbetet med att storskaligt utföra alla uppgraderingar/byten, och projektmedlemmar åker runt i Sverige till företagets olika etableringar/kontor och hjälper till. Projektet förväntas fortlöpa under hela 2025. Projektledaren förväntas inom ramen av detta uppdrag hjälpa till med det operativa uppgraderingsarbetet.

Pågående projekt #2:

Insight till SaaS (100% nov-dec 2024, 10% jan-mar 2025)

Kunden driftar idag Insera:s Insight Budget & Prognos själva, men ska nu flytta till Inseras SaaS-miljö där Insera tar över driften. Arbetet är uppstartsfas. Projektet förväntas pågå till feb/mar 2025. Projektledaren förväntas slutföra flytten i Q1 2025 på ca 10%.

Område:

Infra- & Driftenheten på IT
Alla kundens-anställda med dator
Arbetsuppgifter:
Som projektledare för tekniknära IT-projekt ansvarar du för att projekten levererar på sina projektmål, att definierade leverabler realiseras, samt för överlämning av effektmål vid projektens slut.

Du ansvarar för att sammankalla till projekt- och styrgruppsmöten efter behov, samt kommunikation med beställare och eventuella tredjeparter. Du ansvarar förstås för att projekten levererar inom tid, kostnad och kvalitet, samt att nödvändiga justeringar beslutas om i styrgrupp.

Skallkrav:

Tidigare erfarenhet som projektledare av tekniknära IT-projekt.
Kunskaper om Intune, Windows 11 utrullning
Deltagande i eller ledning av projekt där liknande tjänst upphandlats och etablerats
Erfarenhet av toll-gate baserade projektledningsmetodiker
Talar och skriver flytande svenska
Meriterande krav:

Insera Insight.
Personliga kompetenser:
Leda och följa upp: Leder och pekar ut riktningen för andra. Föregår med gott exempel och är tydlig och rättvis när hen ställer krav och delegerar arbetsuppgifter. Motiverar och stöttar sitt team och ger sina medarbetare möjlighet till utveckling. Har goda kunskaper om rekrytering.

Skapa relationer och nätverk: Skapar goda relationer till kunder och medarbetare och bygger nätverk. Kommer bra överens med andra och kan hantera konflikter.

Planera och organisera: Sätter tydliga mål, följer upp arbetet utifrån tidplan och deadlines. Planerar arbetet med god framförhållning och använder tiden effektivt. Bemannar projekt med de resurser som behövs.

Leverera resultat och uppfylla kundförväntningar: Har kunden i fokus och ställer höga krav på att arbetet håller hög kvalitet. Arbetar metodiskt för att uppnå projektmål och uppfylla kundens förväntningar.

Placering: Stockholm
Startdatum: 2024-11-01
Slutdatum: 2025-21-31
Omfattning: 100% nov-dec 2024 och 50-75% 2025

Med vänlig hälsning/Best regards

Jonatan Sandberg

Partner Manager

Nikita AB

Tomtebogatan 19

113 39 Stockholm

Mobil +46 73 906 36 57

Email jonatan.sandberg@nikita.se

Ladda ner vår app för att få notiser om lediga uppdrag inom din kompetens.
Ladda ned för iPhone

Ladda ned för Android

Gå gärna med i våra grupper på Linkedin.
För konsultbolag

För egenkonsult

Informationen i detta e-postmeddelande och eventuella bilagor är endast avsedda för adressaterna. Om du har fått detta e-postmeddelande av misstag, kontakta avsändaren och radera e-postmeddelandet från ditt system. Alla personuppgifter behandlas i enlighet med relevanta dataskyddsbestämmelser, särskilt GDPR. https://www.nikita.se/privacy-policy/

Image
