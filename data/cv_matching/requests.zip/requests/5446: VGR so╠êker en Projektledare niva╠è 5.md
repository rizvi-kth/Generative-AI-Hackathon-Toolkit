Image
Hej,
Vår kund Västra Götalandsregionen söker en Projektledare, nivå 5

ID: 5446
Ramavtal: ADDA Inköpscentral – IT-konsulter

Omfattning: 100%
Placering: Göteborg
Avtalstid: 2025-01-01 – 2025-12-31

Uppdragsbeskrivning:
Uppdrag: Projektledare IS/IT-tjänst Millennium och Vårdklient privata vårdgivare
Mål: Säkra go-live till november 2024 (PD1) och bereda mer långsiktiga förutsättningar för go-live vid 2025 (PD2)
Projektets effektmål är att säkerställa att de privata vårdgivarna inom Lagen om valfrihet (Lov) kan använda den vårdinformationsmiljö som definierats i program Millennium så som det planerats. Detta innebär att flera perspektiv och områden behöver säkerställas.
Projektet består av tre delprojekt där projektledaren ansvarar för helheten och säkerställer ett fungerande team samt stöd och förankring inom och utanför program Millennium.
Säkerställa att IS/IT-tjänsten Millennium och vårdklient för privata vårdgivare fungerar så att de kan bedriva vård med samma förutsättningar som vård i egen regi
Ansvara för och samordna ett införande av Millennium hos de privata vårdgivarna
Ta fram IS/IT-avtal samt samordna förankring och påskrift inom VGR och privata vårdgivare inom LOV
SKA-KRAV:
Ha erfarenhet av att driva arbete i komplexa projekt med stort fokus på förändringsarbete och verksamhetsutveckling inom Hälso- och sjukvård
Ha mycket god kommunikativ förmåga, vana att kommunicera på ledningsnivå och ha förmåga att bygga starka relationer med programdeltagare på alla nivåer även i en engelskspråkig miljö
Erfarenhet av vårdinformationsmiljö och vårdprocesser kopplat till paketering av stödjande IS/IT-tjänster
Ansvarat för projekt med uppdrag att ta fram, paketera och erbjuda IS/IT-tjänster till privata vårdgivare inom Hälso- och sjukvård
God kännedom om VGRs organisation då uppdraget spänner över många perspektiv med ansvar fördelat mellan flera staber
Mycket god kännedom om primärvårdens behov av IT-stöd samt kringutrustning
Erfarenhet av att ta fram IS/IT-avtal för privata vårdgivare där VGR är tjänsteleverantör
God kännedom om lagrum kopplat till IT-tjänsteleverans inom Hälso- och sjukvård

BÖR-KRAV (mervärde):
Ha mycket god kunskap om och erfarenhet av Program Millennium i perspektivet privata vårdgivare
Har minst 2 års erfarenhet som projektledare från program Millennium (Framtidens vårdinformationsmiljö)
REFERENS:
Konsulten/konsulterna ska ha erfarenhet av ett liknande uppdrag. Detta styrks genom att ramavtalsleverantören till anbudet bifogar en beskrivning av ett motsvarande uppdrag. Följande uppgifter ska framgå:
Beskrivning av referensuppdrag
Uppdragsgivare
Kontaktperson hos uppdragsgivare
Telefonnummer till kontaktperson
E-postadress till kontaktperson
För att kontrollera att angivna uppgifter är korrekta kan referenten komma att kontaktas via e-post eller telefon. Referenten ska vara vidtalad.

INTERVJU (mervärde):
VGR kommer att genomföra intervju med de konsulter som bedöms ha störst chans att tilldelas uppdraget baserat på offererat timpris och möjligt prisavdrag i Mervärde 1 – erfarenhet.
Tidsram för intervjun:
10 min – teamlead får presentera sig
20 min – Intervjufrågor
CV:
Ska inkludera beskrivningar av hur konsulten uppfyller ska- och börkrav genom tidigare erfarenhet. Samt vara på svenska.

Svarstid & svarssätt:
Vänligen inkom med er intresseanmälan och cv senast 2024-10-18 till ramavtal@chas.se.

Med vänlig hälsning

Chas Partner Network AB
Chas Partner Network | Stubbsundsvägen 11 | S-131 41 Nacka
www.chas.se | ramavtal@chas.se | Direct: 073-517 10 16 : Växel 08-744 55 49
Does you consultant firm/consultant broker need a complete suite of business systems incl. time report. www.oden.bi

Want a new job? Chas was awarded as the best Employer in Europe - in Europes biggest Business Award Competition (European Business Awards)
Need better Business System? If your consultant firm/consultant broker need a complete suite of business systems incl. time report, sales, recruit, revenueand more in one and the same system? Visit www.oden.bi
