Logo

Uppdragsförfrågan

Your source to IT www.d-source.se
ID-REQ2647 Utskicksdatum 18 Oct 2024
Roll: BI-utvecklare
Ort: Stockholm Omfattning: 100%
Startdatum:
Slutdatum:
2024-11-04
2025-12-31
Viktiga erfarenheter se nedan:

Konsulten kommer:
• Bedriva utvecklingsarbete i den tekniska BI lösningen - ETL och rapportdelen
• Säkerställa att leveranserna håller god kvalitet och följer praxis för utvecklings principer • Utforma och utföra enhetstesterna
• Samla in krav
• Delaktig i estimerings-, planerings- och prioriteringsarbete
Läs mer >>>
Svara senast 2024-10-22
För fler aktuella uppdrag
Logo
