Image
Ni finns med på Combitechs distributionslista för partner/konsultuppdrag och får därför denna förfrågan.

Combitech söker Quality Lead, Västerås (100003883)

Beskrivning
Quality Lead

Profile
Typically, black belt background with experience from other industries and companies to bring in best practices and ideas. Solid production experience preferred. Not necessarily in house recruitment (Quality tam can be composed to adjust for direct experience.
The black belt background should ensure the appropriate maturity in LEAN/Six sigma and Risk Management and FMEA.
Used to report and present to upper management. Team player and program champion.

Quality Lead tasks (full scope)
• Lead all program quality related work
• Risk and FMEA management
• Lean/Six Sigma

Quality Lead Tasks
The role purpose is to coordinate all changes and alignment between new equipment, methodology and handling from PACE program to robust and in most cases either new or heavily modified quality processes. The role as quality lead in the program means regular alignment of progress to the transformation lead, reporting to STECO (global and local) and to manage the specific roles connected to quality. Those roles, as identified of today are listed below – but one important task is to further identify needs for tasks or roles.

• QA/QC – a role that ensures quality assurance and quality control aspects. That those are secured towards all requirements and that changes or additions are implemented.
• Equipment Qualification – alignment and lead of all new equipment qualification.
• Process Engineering – ensuring all process engineering specs within the projects between the projects and towards the organization as whole.
• Lean/Six sigma – all relevant aspects for Lean six sigma. Likely this is the same person as the quality lead. Examples could be 5S arrangements for the new plant and waste minimizing in new processes.
• Product specifications – similar to QA/QC all product specifications need to be under control and if needed revised.

The person should sit physically at the program office together with the other program leads and project managers.
The Quality Lead role will be part of the Program Lead Team.

Risk Management and FMEA tasks
The program risk management shall move over to ARM (Associate Risk Management) along with introduction of this role. Use to this method.
The program will also continuously develop Equipment FMEAs and eventually the full process FMEA. Provided the vast amount of functionality, machinery and events this will be extensive. PACE ambition is to pilot the use of a dedicated FMEA software to align requirement follow up. No software has been chosen but experience or awareness of automotive FMEA methodology (AIAG/VDA FMEA handbook and APIS IQ as software) would be a great addition.
The Risk Management role will be part of the Program Execution Team.

LEAN/Six Sigma Tasks
The modern facility needs to follow best practices. The ambition is to handover a state of the art factory, yet the program run time is long. The need for continuous improvement already during program execution is obvious. New processes need to be set up in efficient ways. Work place arrangement and methodology need to be minimizing waste of resources and material.
LEAN/Six Sigma tools are proven to take care of all this and this subordinate role to the quality lead is likely within the same person in the ideal setup.

Role Commitment
The full role scope including all three parts would be one Full Time Employee (FTE). It is particularly expressed from global leaders that the program leading team would consist of dedicated program resources.

---

Arbetsuppgifter
Definiera kvalitetsrelaterade KPI:er och kapabilitetsmätetal.
Leda och driva områdena för kvalificeringar, FMEA, QC/QA, processutveckling, produktspecifikationer, Lean.
Uppdraget innebär att definiera aktiviteter inom ovanstående områden som krävs för att nå önskat utfall och sedan leda dessa områden tvärfunktionellt mot de individuella projekt som drivs inom programmet.
Övergripande ansvar för kvalitetssäkring i program koordinerat mot de individuella projekten inom programmet.

Profil
• Utbildning: Teknisk utbildning inom Högskola/universitet med inriktning på industriteknik.
• Krav: 5-10 års erfarenhet inom införande av program/projekt inom industritillämpningar med hög automatiseringsgrad och kvalitetskrav 10+ erfarenhet inom tillverkande industri.
• Önskvärt: Arbete inom kärnteknisk industri.
• Program/systemkunskap: Lean/Six Sigma FMEA Kvalificeringar Processutveckling.
• Språk: Svenska och engelska flytande.

Uppdragsinformation
Uppdragslängd: start snarast – ca 2025-01-31
Placeringsort: Västerås

Svar önskas snarast, dock senast 2024-10-28.

För ytterligare frågor kontakta:
Tezcan Can, tezcan.can@combitech.com

Är ni intresserad, har tillgänglig och passande konsult för uppdraget, svara till partner.network@combitech.se och bifoga:

- Kompetensprofil (CV)
- Förslag på pris
- Tillgänglighet
- Hemort för kandidat
- Denna förfrågans ID
  (inkludera gärna hela denna förfrågan i ert svar)

För fler lediga konsultuppdrag besök Combitechs hemsida.
Om du inte längre vill få förfrågningar från Combitech, avbeställ genom att svara på detta mail.Combitech
