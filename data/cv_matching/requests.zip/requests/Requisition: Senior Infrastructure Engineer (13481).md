Image
Show Requisition - Senior Infrastructure Engineer (13481)
Hello!

We're searching for a skilled infrastructure engineer from November/December. Please send me a resume if you have a suitable, relevant candidate available then.

Thanks!

To: B3 Consulting Group AB
Requisition - Details

Title Senior Infrastructure Engineer
Id 13481
Offer due date MISSING
Description Tasks & Responsibilities:

Ensure security, availability, performance, scalability, and automation of infrastructure.
Collaborate closely with global teams, both local and remote.
Ensure continuous monitoring and measurement of infrastructure.
Maintain and enhance CI/CD pipelines for seamless product delivery and quality improvement.
Lead infrastructure projects, influencing company-wide decisions and implementing new technologies.
Coordinate complex projects across multiple teams.
Participate actively in peer projects through code reviews and collaboration, mentoring fellow engineers.

Skills & Experience:
Sysadmin background is essential.
10+ years in infrastructure and networking.
Expertise in deployment and orchestration tools (e.g., Kubernetes, Docker, Ansible, Terraform).
Strong scripting and programming abilities.
Proficient in Infrastructure as Code.
Experience managing solutions on GCP required. Also some on-prem infrastructure to handle. AWS and/or Azure would also be beneficial.
GitOps experience
Istio is merited
You probably have a background as a technician rather than developer.

Hybrid work - 2-3 days/week at the office in Stockholm.
6 months contract initially
Start in November or December.
Must participate in an on-call rotation.
Location Stockholm
Competence area Sysadmin
Start date 2024-10-02
End date Open
Quantity 0
Unit Hour
Work time percentage 100%
Auction Closed - Anonymous

--
Sara Hagström
Partner Relations
Tingent AB (publ)
sara@tingent.se
Cell phone: 0724 020 962
