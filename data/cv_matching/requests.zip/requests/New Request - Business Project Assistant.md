logo
New Request - Business Project Assistant
Dear ,

Emagine are now looking for Business Project Assistant to one of our amazing banking clients.

Start date: 2024-11-01

End date: 2025-06-30
Location: Stockholm (3 days onsite, 2 days remote)
Price: 525 SEK to Consultant

Detailed description of work task to be carried out

o Meeting coordinator and secretariat

o We need someone to support with the restructuring, facilitation, and running of two committees:

• Tasks will include (and not be limited to):

o Scheduling meetings

o Identifying and communicating with participants

o Proactively get input from Chair on pipeline of topics for the meeting

o Identifying and communicating with Speakers for the meeting

o Make sure that the speakers will create the material, and in time for sending it to meeting participants before the meetings

Project execution:

Coordinate the deliverables in projects and also implement the deliverables in some cases. Need someone to be able to understand the project topics, what the deliverables are about, and drive deliverables with stakeholders and also create the work product themselves. For example, working with existing templates – making sure the stakeholders understand how to fill out the templates, keep track of deadlines and proactively warn stakeholders of upcoming deadlines, and fill out the templates themselves and upload them to the respective areas.

Team support: Be able to attend meetings, provide updates to members of the team. Also structure the team tasks in excel or kanban (or similar), create ppt material for team meetings, etc.

Description of knowledge and experience

Previous Banking experience is a MUST

Knowledge of data governance is a plus

Experience with project execution/implementation is a plus

Endi Dedic
Business Manager
endi@emagine-consulting.se
+46 73 802 21 02

This email is confidential. If you did not request this email, or if you think it got delivered to the wrong email address, please let us know, and then delete the message from your system.
