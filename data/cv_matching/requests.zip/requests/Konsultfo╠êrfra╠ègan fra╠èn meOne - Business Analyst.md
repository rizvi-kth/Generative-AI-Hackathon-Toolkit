Hej,

Vi har mottagit en förfrågan och letar efter en konsult i enlighet med:

Roll: Business Analyst

Omfattning: 100%

Startdatum: 2024-11-04 ASAP

Slutdatum: 2025-10-31

Placeringsort: Stockholm /Hybrid

Beskrivning av uppdraget:

Vi söker en Business Analyst med kunskap om försäkringsbranchen samt med Life400 erfarenhet, som har vana att identifiera affärsproblem, föreslå lösningar och underlätta kommunikationen mellan olika affärsenheter och intressenter.

Uppdraget innebär bla att:

- Svara på allmänna frågor kring funktionalitet från användare och övriga intressenter av Life400
- Hantera upphandlingar och försäkringserbjudanden
- Hantera rapporter och sökningar via queries
- Hantera/analysera beställningar och förändringsuppdrag
- Testa systemförändringar från ett verksamhetsperspektiv innan produktionssättning.

Jobbet kan göras mestadels remote, men man bör vara lokaliserad i Stockholmtrakten då kundmöten i Stockholm förekommer.

Kompetenskrav:

- Life400
- Polisy400
- Group400

Övrigt:

svensktalande är ett plus men inget krav.

Jobbet kan göras mestadels remote, men man bör vara lokaliserad i Stockholmtrakten då kundmöten i Stockholm kan förekomma.

Vi ser fram emot att få en offert så snart som möjligt, dock senast, 2024-10-25

Vänligen svara på detta mejl med din offert/konsultprofiler enligt:

önskad timdebitering
konsultmotivering
startdatum när du kan börja
uppdaterat och anpassat CV i Word format

Med vänliga hälsningar/Best regards

Image
Tomas Lanneborn
Regional Director, East

Mobile ++46 709 401 671
Web www.meone.se | E-mail tomas.lanneborn@meone.se
Address Torshamnsgatan 35, 164 40 Kista, Sweden

​
