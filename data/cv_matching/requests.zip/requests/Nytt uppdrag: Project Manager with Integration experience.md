logo
Nytt uppdrag: Project Manager with Integration experience
Hej!

Vi letar efter en projektledare som specifikt har jobbat med integrationer.

Återkoppla med CV om du har någon.

Rollbeskrivning:

We are looking for a Project Leader who can help our client with their Integration Platform Vendor Selection Project. The goal of the project is to select the future Integration Platform vendor and prepare for a follow-on implementation phase. You need to have integration platform know-how and be able to lead the project to select the vendor and work together with the internal technical, architect and procurement teams.

Start: ASAP

Length: 6 months with possible extension

Location: Stockholm/hybrid

Project Objectives

The project will undertake a competitive vendor selection process with pre-selected short-listed vendors, to select the future integration platform. The project will include:

• Documentation of project requirements including functionality, performance and scalability needs

• A thorough analysis of short-listed vendors to assess suitability.

• Draft and manage the Request for Proposal (RFP) documentation, together with the internal GlobalConnect procurement function.

• Facilitate vendor presentations, demonstrations and Q&A sessions.

• Evaluate proposals based on the defined requirements and perform comparative analysis

• Stakeholder management throughout the process.

• Present final recommendations based on a thorough evaluation of vendor capabilities, costs and alignment with business needs.

• Lead contract negotiations and coordinate with legal and procurement teams for final vendor engagement.

Deliverables

The deliverables from the project include:

• Requirements documentation

• Vendor shortlist competitive analysis report

• RFP document

• Vendor evaluation matrix and final recommendation report

• Draft contract and negotiation summary

The project is expected to take 2-3 months to complete, with the following key milestones:

· Requirements finalisation: 15th November 2024

· RFP release: 30th November 2024

· Final recommendation and selection : 31st January 2025

Required Expertise

• Proven experience in project management, specifically in vendor selection and procurement processes.

• Strong knowledge of integration platforms.

• Excellent communication and stakeholder management skills.

Boris Batljan
Sales Manager
boris@emagine-consulting.se
+46 739 60 12 82
