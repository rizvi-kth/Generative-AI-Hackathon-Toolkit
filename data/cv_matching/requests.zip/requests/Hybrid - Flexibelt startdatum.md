Hejsan,

För Partners räkning söker vi en Projektledare ERP implementering enligt nedan.
https://uppdrag.interagent.se/jobs/1744-projektledare-erp-implementation

Projektledare för ERP-implementering
Vi söker en erfaren projektledare för att driva en omfattande ERP-implementering. Kunden ska implementera Microsofts ERP-lösning i Sverige, vilket omfattar både huvudkontor och ett flertal butiker runtom i landet.

Om rollen:
Som projektledare kommer du att ha huvudansvaret för att leda och koordinera projektet från start till mål. Implementeringen är heltäckande och inkluderar samtliga affärsprocesser, från logistikflöden och ekonomi till inköp, materialhantering och POS (Point of Sale). Du kommer att arbeta nära både kundens interna team och externa leverantörer för att säkerställa att projektet levereras enligt tidsplan, budget och med högsta kvalitet.

Dina ansvarsområden inkluderar:
Leda och styra ERP-implementeringsprojektet genom hela projektets livscykel, från planering till avslut.
Ansvara för tidplanering, budget och riskhantering.
Samordna med funktionella team inom logistik, ekonomi, inköp, materialhantering och POS.
Kommunicera löpande med projektets intressenter för att säkerställa att deras krav och förväntningar uppfylls.
Säkerställa att lösningen är anpassad och optimerad för kundens specifika behov.
Dokumentera och rapportera projektets framsteg till styrgrupp och ledning.

Vi söker dig som har:
Erfarenhet av att leda ERP-implementeringsprojekt, gärna inom Microsofts ERP-lösningar (Dynamics 365 eller liknande).
Stark projektledningskompetens, med förmåga att hålla samman komplexa projekt med många intressenter.
Erfarenhet av att arbeta med affärsprocesser inom logistik, ekonomi, inköp och POS.
Meriterande med erfarenhet av projekt inom retail

Vid intresse att presentera konsult för detta uppdrag tar vi tacksamt emot offert innehållande.
CV (gärna i word)
Timpris
Tillgänglighetsdatum

Med vänliga hälsningar

Magnus Ahlström
0707-157 157 magnus@interagent.se

Andreas De Freitas
072-319 51 05
andreas@interagent.se

Image
