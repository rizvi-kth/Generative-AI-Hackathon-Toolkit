Image
Hej,
Vår kund Region Dalarna söker en Systemutvecklare fullstack, nivå 4

ID: RS2024/1807

Omfattning: 100 - 75 - 50%
Placering: Falun
Avtalstid: Vid avtalsteckning – 2025-06-30, med option till förlängning med 12 månader

Uppdragsbeskrivning:
Uppdraget består i att ta rollen som fullstackutvecklare och vidareutveckla/anpassa funktionaliteten i LOVE till att passa Region Dalarnas förutsättningar. Beräknad omfattning för uppdraget 100% månad 1-4, 75% månad 5, sedan 50%.
Som utvecklare har du även ansvaret för lösningsarkitekturen och förväntas självständigt driva utvecklingen och aktivt föreslå tekniska lösningar och förbättringsförslag. Du kommer att samarbeta med de team som jobbar med Systemintegrationer/systemutveckling (ICC) och Business Intelligence Landstinget Dalarna (BILD). Du kommer också att stötta interna utvecklare så att de framöver kan förvalta och driva utvecklingen vidare.
LOVE är en C# .NET webapplikation med gränssnitt i ASP.NET Model View Controller (HTML, CSS, JavaScript, Bootstrap) samt ett datalager i Entity Framework, SQL Server och Hangfire för asynkrona jobb

Windows Server, IIS och SQL Server används för hostning, Active Directory inloggning (AD) för behörighetslösning.
Azure DevOps till continuous integration/delivery (CI/CD) och Git för källkodshantering.

Uppdraget innebär bland annat
uppsättning och driftsättning av webbapplikation samt tillhörande datalager
implementation av behörighetslösning med AD-inloggning
integration med system och datalager för att göra data tillgängligt i LOVE som krävs för beräkning av ersättning
anpassa LOVE’s domänlogik efter verksamhetens behov

SKA-KRAV:
Efterfrågad konsult ska ha genomfört minst två (2) längre och komplexa uppdrag där konsulten haft en ledande roll som utvecklare och arkitekt vid genomförandet
Efterfrågad konsult ska ha minst 6 års erfarenhet av C# .NET-utveckling av backend/tjänstelager
Efterfrågad konsult ska ha dokumenterad erfarenhet av HTML, CSS och JavaScript
Efterfrågad konsult ska ha dokumenterad erfarenhet av ASP.NET Model View Controller (MVC)
Efterfrågad konsult ska ha dokumenterad erfarenhet av minst två större uppdrag där Entity Framework och SQL Server använts
Efterfrågad konsult ska ha dokumenterad erfarenhet av uppsättning och konfiguration av IIS webbserver och SQL Server databas för hostning

BÖR-KRAV (mervärde):
Offererad konsult bör ha dokumenterad erfarenhet av Bootstrap för frontendutveckling
Offererad konsult bör ha erfarenhet av Azure DevOps för continuous integration/delivery (CI/CD) och Git för källkodshantering
Offererad konsult bör ha dokumenterad erfarenhet av applikationer som hanterar hälso- och sjukvårdsdata
Offererad konsult bör ha dokumenterad erfarenhet av att utveckla behörighetslösningar med AD-inloggning
Offererad konsult bör ha dokumenterad erfarenhet av integrationer och REST API:er

REFERENS:
Leverantören ska redovisa ett (1) referensuppdrag för offererad konsult som ska vara av liknande karaktär enligt denna avropsförfrågan och ej vara äldre än tre (3) år räknat från anbudstidens utgång.
Följande information ska redovisas:
beskrivning av uppdraget
tidsperiod då uppdraget utfördes
kontaktuppgifter till referensperson (uppdragsgivare)

Regionen förbehåller sig rätten att utifrån den i anbudet skriftliga beskrivningen av uppdraget avgöra om det kan räknas vara av liknande karaktär enligt efterfrågat uppdrag.

INTERVJU (mervärde):
Region Dalarnas uppdragsgivare har avsatt tid för intervju under vecka 45.

CV:
Intervjun kommer att ske i på distans över Teams och bedöms omfatta cirka 45 minuter med inledning, intervjufrågor och avslutning. Projektgruppen som utför intervjun kommer att representeras av uppdragsgivaren.
Ska inkludera beskrivningar av hur konsulten uppfyller ska- och börkrav genom tidigare erfarenhet. Samt vara på svenska.

Svarstid & svarssätt:
Vänligen inkom med er intresseanmälan och cv senast 2024-10-22 till ramavtal@chas.se.

Med vänlig hälsning

Chas Partner Network AB
Chas Partner Network | Stubbsundsvägen 11 | S-131 41 Nacka
www.chas.se | ramavtal@chas.se | Direct: 073-517 10 16 : Växel 08-744 55 49
Does you consultant firm/consultant broker need a complete suite of business systems incl. time report. www.oden.bi

Want a new job? Chas was awarded as the best Employer in Europe - in Europes biggest Business Award Competition (European Business Awards)
Need better Business System? If your consultant firm/consultant broker need a complete suite of business systems incl. time report, sales, recruit, revenueand more in one and the same system? Visit www.oden.bi
