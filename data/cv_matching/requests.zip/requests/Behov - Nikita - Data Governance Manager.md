Hej!

Vi har fått in en mycket rolig förfrågan från kund inom bostadsförvaltning som nu söker en Data Governance Manager för ett interimsuppdrag i 7 månader på 60% med start omgående för överlämning.

Bakgrund:
Kunden jobbar nu i ett projekt med syfte att få till en datastyrning (s.k DataGovernance) och förbättra datakvaliteten i bolaget. Mycket är under uppbyggnad men de har tagit approachen att istället för att göra ett teoretiskt projekt (vilket ofta datastyrningsprojekt blir) så vill de även lösa en del kvalitetsproblem samt bestämma datastandarder.
I projektet jobbar man med en verksamhetsutvecklare, IT arkitekt samt informationsägare/ansvarig. På större bolag så om man är Data Governance Manager kan det vara så att man inte grottar i detaljer men hos kunden är man involverad i vissa detaljer.

Arbetsuppgifter:
Datakvalitetsansvarig ansvarar för att organisationens data är av hög kvalitet och uppfyller de krav som ställs på korrekthet, fullständighet, aktualitet och konsistens. Datakvalitetsansvarig arbetar både med datastyrning (DataGovernance) samt datakvalitet.

Huvuduppgift är att säkerställa att data som används i organisationens olika processer är pålitlig och användbar genom att:

Utveckla, implementera datastyrningsramverk: Skapa en struktur eller ett ramverk för datastyrning som specificerar hur data ska hanteras i organisationen. Detta inkluderar riktlinjer och policys för ägandeskap, livscykel, standarder, begreppsmodeller för hantering av data
Definiera datastyrningspolicyer: Utarbeta policyer och regler för att säkerställa datakvalitet, datasäkerhet, åtkomst och efterlevnad av dataskyddsföreskrifter (som GDPR). Dessa policyer specificerar riktlinjer för hur data ska samlas in, användas och skyddas
Övervakning och uppföljning av datastyrning: Implementera och övervaka processer för att säkerställa att datastyrningsramverket följs. Detta kan innebära att övervaka efterlevnaden av datastyrningsprinciper och hantera avvikelser för att säkerställa att data används korrekt
Dataägande och datasamordning: Samordna och stödja informationsägare i att säkerställa att rätt data är tillgänglig och används på rätt sätt. Detta innebär att arbeta nära andra funktioner inom organisationen för att se till att datakvalitet, datasäkerhet och dataintegritet upprätthålls.
Definiera datastandarder: tillsammans med verksamhet samla in informationsbehov och utveckla och definiera datastandarder för olika informationsområden vad gäller begrepp, attribut och värden på data.
Dataanalys: genomföra analyser av data för att identifiera fel, brister eller inkonsekvenser. Detta innebär att använda verktyg och tekniker för att upptäcka problem med datakvalitet, som dubblerad data, saknade värden eller inkonsekventa format
Datavalidering och kontroll: Utveckla processer för validering och kontroll av data för att säkerställa att data är korrekt. Detta innebär ofta att sätta upp automatiserade valideringsregler och manuella kontroller för att garantera datakvalitet.
Datakatalog och metadatahantering: Ansvara för att upprätthålla en datakatalog som innehåller en lista över organisationens olika datakällor och deras användning. Detta kan inkludera hantering av metadata, vilket innebär att säkerställa att data är korrekt beskriven och dokumenterad så att den blir lättare att förstå och använda.
Utbildning och medvetenhet: Skapa och genomföra utbildningsprogram för att öka medvetenheten om datastyrning och datakvalitet inom organisationen. Detta innebär att hjälpa anställda att förstå vikten av datastyrning och deras roll i att följa etablerade riktlinjer och policys.
Skallkrav

Kunskaper i datastyrning och ramverk:

Data Governance Frameworks: Förståelse för ramverk och principer för datastyrning, t.ex. DAMA-DMBOK (Data Management Body of Knowledge), och erfarenhet av att implementera styrningsramverk i organisationer.
Datastandard: Erfarenhet av att etablera datastandarder, jobba med informationsmodeller och begrepp
Datahanteringspolicyer: Erfarenhet av att utforma och implementera policyer och riktlinjer för datastyrning.
Teknisk kompetens:

Databashantering och dataarkitektur: Förståelse för hur data organiseras, lagras och hanteras i databaser samt kunskaper om databasdesign och dataarkitektur.
Datakvalitetsverktyg: Erfarenhet av att arbeta med verktyg och plattformar för datakvalitet, såsom Informatica, Collibra, Talend, eller andra verktyg som används för datastyrning, profilering och analys.
Metadatahantering: Förståelse för hantering av metadata och kunskaper om hur man upprätthåller datakataloger och hanterar data i hela livscykeln.
Dataanalys: Grundläggande kunskaper i dataanalys och verktyg som Excel, SQL eller BI-verktyg (t.ex. Tableau eller Power BI) för att förstå, analysera och rapportera data.
Ledarskapsförmågor:

Projektledning: Förmåga att leda och hantera projekt som rör datastyrning, inklusive att organisera och samordna resurser och säkerställa resultat.
Förändringsledning: Erfarenhet av förändringsledning och förmåga att driva förändringar och införa nya riktlinjer och processer för datastyrning i organisationen.
Kommunikation och påverkansförmåga: God förmåga att kommunicera värdet av datastyrning till olika intressenter, inklusive ledningen, och få med sig hela organisationen genom tydlig och pedagogisk kommunikation.
Analytiska och problemlösande färdigheter:

Analytisk tänkande: Förmåga att analysera dataprocesser och identifiera förbättringsområden relaterade till datakvalitet, datasäkerhet och effektivitet i dataanvändning.
Problemlösning: Stark problemlösningsförmåga för att hantera dataincidenter och utmaningar som kan uppstå under implementeringen av nya datastyrningspolicyer.
Erfarenhet:

Branscherfarenhet: Kunskap om fastighetsbranschen och dess specifika behov, affärsprocesser och branschstandarder, för att kunna anpassa datastyrningen så att den ger största möjliga nytta för organisationen.
Erfarenhet av datadriven kultur: Erfarenhet av att driva eller stödja en datadriven kultur, där data används strategiskt för att fatta välgrundade beslut.
Tidigare roller: arbetat som Data Quality manager, Data Governance manager, Data Manager, informationsägare, informations eller dataarkitekt
Start: Omgående
Omfattning: 60% (3 dagar i veckan)
Längd: 7 månader
Slut: 2025-05-30

Med vänlig hälsning/Best regards

Fredrik Åqvist Wilbrand
Partner Manager

Nikita AB
Tomtebogatan 19
113 39 Stockholm

Mobil +46 70 233 32 29
Email fredrik.a.w@nikita.se

Ladda ner vår app för att få notiser om lediga uppdrag inom din kompetens.
Ladda ned för iPhone
Ladda ned för Android

Gå gärna med i våra grupper på Linkedin.
För konsultbolag
För egenkonsult

Informationen i detta e-postmeddelande och eventuella bilagor är endast avsedda för adressaterna. Om du har fått detta e-postmeddelande av misstag, kontakta avsändaren och radera e-postmeddelandet från ditt system. Alla personuppgifter behandlas i enlighet med relevanta dataskyddsbestämmelser, särskilt GDPR. https://www.nikita.se/privacy-policy/

Image
